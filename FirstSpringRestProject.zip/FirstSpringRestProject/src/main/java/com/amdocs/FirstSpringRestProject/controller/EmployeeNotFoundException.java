package com.amdocs.FirstSpringRestProject.controller;


public class EmployeeNotFoundException extends RuntimeException {

    public EmployeeNotFoundException() {
        // TODO Auto-generated constructor stub

    }

    public EmployeeNotFoundException(String message) {
        // TODO Auto-generated constructor stub
        super(message);
    }
}


