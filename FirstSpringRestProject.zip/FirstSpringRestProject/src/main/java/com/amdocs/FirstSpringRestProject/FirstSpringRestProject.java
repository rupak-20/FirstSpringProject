package com.amdocs.FirstSpringRestProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSpringRestProject {

    public static void main(String[] args) {
        SpringApplication.run(FirstSpringRestProject.class, args);
    }

}
