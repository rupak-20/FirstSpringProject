package com.amdocs.FirstSpringRestProject.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Connection;
import java.sql.DriverManager;

@RestController
@RequestMapping("/api")

public class TestDBController {
    String connectionUrl = "jdbc:oracle:thin:@localhost:1521:XE";
    String jdbcDriver = "oracle.jdbc.driver.OracleDriver";
    String userName = "scott";
    String passWord = "tiger";

    @GetMapping("/testdb")
    public String testDb() {
        try {

            Class.forName(jdbcDriver);
            Connection con = DriverManager.getConnection(connectionUrl, userName, passWord);
            return "Successsfully Connected to" + connectionUrl;


        } catch (Exception E) {
            E.printStackTrace();
        }
        return "Cannot Connect to Db!!!";
    }

}
