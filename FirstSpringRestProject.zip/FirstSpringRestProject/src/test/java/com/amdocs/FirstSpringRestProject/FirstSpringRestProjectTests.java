package com.amdocs.FirstSpringRestProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringRestProjectTests {

	@Test
	void contextLoads() {
	}

}
